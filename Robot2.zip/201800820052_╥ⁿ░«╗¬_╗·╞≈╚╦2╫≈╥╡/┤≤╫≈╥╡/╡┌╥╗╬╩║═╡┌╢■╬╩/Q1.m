clc,clear 
%% 创建机械臂(关节的运动速度没有直接限制的参数)
L(1)=Link([0,0,0,pi/2],'qlim',[-2*pi,2*pi]);%构建连杆1
L(2)=Link([pi/2,86.85,243.65,0],'qlim',[-2*pi,2*pi]);%构建连杆2
L(3)=Link([0,-92.85,213,0],'qlim',[-2*pi,2*pi]);%构建连杆3
L(4)=Link([-pi/2,83.4,0,pi/2],'qlim',[-2*pi,2*pi]);%构建连杆4
L(5)=Link([0,-83.4,0,-pi/2],'qlim',[-2*pi,2*pi]);%构建连杆5
L(6)=Link([0,100,0,0]);%构建连杆6
Planer6R=SerialLink(L,'name','UR3');%建立机器人
figure(3)
view(3);
Planer6R.plot([0 pi/2 0 pi*3/2 0 0]) %展示初始位姿
%% Q1
syms theta1 theta2 theta3 theta4 theta5 theta6 d2 d3 d4 d5 d6 a2 a3
T1=trotz(theta1)*trotx(90,'deg');
T2=trotz(theta2+pi/2)*transl(0,0,d2)*transl(a2,0,0);
T3=trotz(theta3)*transl(0,0,-d3)*transl(a3,0,0);
T4=trotz(theta4-pi/2)*transl(0,0,d4)*trotx(90,'deg');
T5=trotz(theta5)*transl(0,0,-d5)*trotx(-90,'deg');
T6=trotz(theta6)*transl(0,0,d6);
% T=T1*T2*T3*T4*T5*T6
%消掉pi/2
T2=[[ -sin(theta2), -cos(theta2), 0, -a2*sin(theta2)];
    [  cos(theta2), -sin(theta2), 0,  a2*cos(theta2)];
    [            0,            0, 1,              d2];
    [            0,            0, 0,               1]]
T4=[[ sin(theta4), 0,  -cos(theta4),  0];
    [ -cos(theta4), 0, -sin(theta4),  0];
    [     0,       1,   0,            d4];
    [     0,       0,   0,             1]]
T=T1*T2*T3*T4*T5*T6%计算最终位姿矩阵
 %% Q2求T16的两种矩阵表示
 syms theta1 theta2 theta3 theta4 theta5 theta6 d2 d3 d4 d5 d6 a2 a3 nx ox ax px ny oy ay py nz oz az pz
 T1_inv=[[ cos(theta1),sin(theta1), 0, 0];[0, 0, 1, 0];[ sin(theta1), -cos(theta1), 0, 0];[0,  0, 0, 1]];
 TT=[[nx,ox,ax,px];[ny,oy,ay,py];[nz,oz,az,pz];[0,0,0,1]];
 T=[[theta1 theta1 theta1 theta1];[theta1 theta1 theta1 theta1];[theta1 theta1 theta1 theta1];[theta1 theta1 theta1 theta1]];
 % 用手动化简后的结果更新变换矩阵
 T(1,1)=cos(theta6)*(sin(theta1)*sin(theta5)+cos(theta5)*cos(theta1)*cos((theta2)+(theta3)+(theta4)))-sin(theta6)*cos(theta1)*sin((theta2)+(theta3)+(theta4));
 T(1,2)=sin(theta6)*(sin(theta1)*sin(theta5)+cos(theta5)*cos(theta1)*cos((theta2)+(theta3)+(theta4)))-cos(theta6)*cos(theta1)*sin((theta2)+(theta3)+(theta4));
 T(1,3)=cos(theta5)*sin(theta1)-sin(theta5)*cos(theta1)*cos((theta2)+(theta3)+(theta4));
 T(1,4)=d6*(cos(theta5)*sin(theta1)-sin(theta5)*cos(theta1)*cos((theta2)+(theta3)+(theta4)))-d5*cos(theta1)*sin((theta2)+(theta3)+(theta4))+(d2-d3+d4)*sin(theta1)-a2*cos(theta1)*sin(theta2)-a3*cos(theta1)*sin((theta2)+(theta3));
 T(2,1)=-cos(theta6)*(cos(theta1)*sin(theta5)-cos(theta5)*sin(theta1)*cos((theta2)+(theta3)+(theta4)))-sin(theta6)*sin(theta1)*sin((theta2)+(theta3)+(theta4));
 T(2,2)=sin(theta6)*(cos(theta1)*sin(theta5)-cos(theta5)*sin(theta1)*cos((theta2)+(theta3)+(theta4)))-cos(theta6)*sin(theta1)*sin((theta2)+(theta3)+(theta4));
 T(2,3)=-sin(theta5)*sin(theta1)*cos((theta2)+(theta3)+(theta4))-cos(theta1)*cos(theta5);
 T(2,4)=(d3-d2-d4)*cos(theta1)-d5*sin(theta1)*sin((theta2)+(theta3)+(theta4))-d6*(cos(theta1)*cos(theta5)+sin(theta5)*sin(theta1)*cos((theta2)+(theta3)+(theta4))) -a2*sin(theta1)*sin(theta2)-a3*sin(theta1)*sin((theta2)+(theta3));
 T(3,1)=sin(theta6)*cos((theta2)+(theta3)+(theta4))+cos(theta5)*cos(theta6)*sin((theta2)+(theta3)+(theta4));
 T(3,2)=cos(theta6)*cos((theta2)+(theta3)+(theta4))-cos(theta5)*sin(theta6)*sin((theta2)+(theta3)+(theta4));
 T(3,3)=-sin(theta5)*sin((theta2)+(theta3)+(theta4));
 T(3,4)=a2*cos(theta2)+d5*cos((theta2)+(theta3)+(theta4))+a3*cos((theta2)+(theta3))-d6*sin(theta5)*sin((theta2)+(theta3)+(theta4));
 T(4,1)=0;T(4,2)=0;T(4,3)=0;T(4,4)=1;
 T16_1=T1_inv*TT;%T16第一种表示
 T16_2=T1_inv*T;%T16第二种表示