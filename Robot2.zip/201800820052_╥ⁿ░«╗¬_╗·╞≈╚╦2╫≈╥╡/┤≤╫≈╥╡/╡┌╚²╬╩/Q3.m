clc,clear 
%% 创建机械臂
L(1)=Link([0,0,0,pi/2],'qlim',[-2*pi,2*pi]);%构建连杆1
L(2)=Link([pi/2,86.85,243.65,0],'qlim',[-2*pi,2*pi]);%构建连杆2
L(3)=Link([0,-92.85,213,0],'qlim',[-2*pi,2*pi]);%构建连杆3
L(4)=Link([-pi/2,83.4,0,pi/2],'qlim',[-2*pi,2*pi]);%构建连杆4
L(5)=Link([0,-83.4,0,-pi/2],'qlim',[-2*pi,2*pi]);%构建连杆5
L(6)=Link([0,100,0,0],'m',1);%构建连杆6
UR3=SerialLink(L,'name','UR3');%建立机器人
%% xoz平面上“山大”轨迹
z1=fliplr(0:0.05:2);x1=6*ones(1,length(z1));%竖
x2=fliplr(0:0.05:6);z2=0*ones(1,length(x2));%横
z3=fliplr(0:0.05:4);x3=3*ones(1,length(z3));%竖
z4=fliplr(0:0.05:2);x4=0*ones(1,length(z4));%竖
x5=fliplr(-5:0.05:-1);z5=3*ones(1,length(x5));%横
z6=fliplr(3:0.05:4);x6=-3*ones(1,length(z6));%竖
x7=-3:0.05:-1;z7=-1.5*x7-1.5;%撇
x8=fliplr(-5:0.05:-3);z8=1.5*x8+7.5;%捺
%% xoz平面投影到xyz三维空间
arry_XZ=[[x1',z1'];[x2',z2'];[x3',z3'];[x4',z4'];[x5',z5'];[x6',z6'];[x7',z7'];[x8',z8']];
y1=30*sqrt(64-x1.^2-z1.^2)-700;
y2=30*sqrt(64-x2.^2-z2.^2)-700;
y3=30*sqrt(64-x3.^2-z3.^2)-700;
y4=30*sqrt(64-x4.^2-z4.^2)-700;
y5=30*sqrt(64-x5.^2-z5.^2)-700;
y6=30*sqrt(64-x6.^2-z6.^2)-700;
y7=30*sqrt(64-x7.^2-z7.^2)-700;
y8=30*sqrt(64-x8.^2-z8.^2)-700;
arry_Y=sqrt(64-arry_XZ(:,1).^2-arry_XZ(:,2).^2);
arry_XYZ=[30*arry_XZ(:,1)-50,30*arry_Y-700,30*arry_XZ(:,2)]; 
%% 画图
figure,
Pos0=[0,pi/2,0,pi*3/2,0,0];%初始位姿
view(3);UR3.plot(Pos0);
hold on
[X,Y,Z] = sphere;
r = 240;
X2 = X * r;Y2 = Y * r;Z2 = Z * r;
surf(X2-50,Y2-700,Z2)

hold on
scatter3(arry_XYZ(:,1),arry_XYZ(:,2),arry_XYZ(:,3),'r','fill','LineWidth',2)
%% 轨迹规划
% 竖
for i=1:length(x1)
    A1=transl(30*x1(i)-50,y1(i),30*z1(i));
    theta=UR3.ikine(A1,'mask',[1 1 1 0 0 0]);
    UR3.plot(theta)
end
% 横
for i=1:length(x2)
    A1=transl(30*x2(i)-50,y2(i),30*z2(i));
    theta=UR3.ikine(A1,'mask',[1 1 1 0 0 0]);
    UR3.plot(theta)
end
% 竖
for i=1:length(x3)
    A1=transl(30*x3(i)-50,y3(i),30*z3(i));
    theta=UR3.ikine(A1,'mask',[1 1 1 0 0 0]);
    UR3.plot(theta)
end
% 竖
for i=1:length(x4)
    A1=transl(30*x4(i)-50,y4(i),30*z4(i));
    theta=UR3.ikine(A1,'mask',[1 1 1 0 0 0]);
    UR3.plot(theta)
end
% 横
for i=1:length(x5)
    A1=transl(30*x5(i)-50,y5(i),30*z5(i));
    theta=UR3.ikine(A1,'mask',[1 1 1 0 0 0]);
    UR3.plot(theta)
end
% 竖
for i=1:length(x6)
    A1=transl(30*x6(i)-50,y6(i),30*z6(i));
    theta=UR3.ikine(A1,'mask',[1 1 1 0 0 0])
    UR3.plot(theta(1,:))
end
% 撇
for i=1:length(x7)
    A1=transl(30*x7(i)-50,y7(i),30*z7(i));
    theta=UR3.ikine(A1,'mask',[1 1 1 0 0 0]);
    UR3.plot(theta)
end
% 捺
for i=1:length(x8)
    A1=transl(30*x8(i)-50,y8(i),30*z8(i));
    theta=UR3.ikine(A1,'mask',[1 1 1 0 0 0]);
    UR3.plot(theta)
end