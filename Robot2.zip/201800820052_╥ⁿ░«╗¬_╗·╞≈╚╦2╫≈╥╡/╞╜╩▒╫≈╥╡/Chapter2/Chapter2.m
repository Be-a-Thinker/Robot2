%atan2(sin值,cos值)可以判断确定的象限
%% Q1 求相对于参考坐标系的位置
T=troty(60,'deg')*trotx(30,'deg');
P=[1;2;3;1];
P_1=T*P;
%% Q2
T=trotz(90,'deg')*transl(5,3,6)*trotx(90,'deg');%求总的变换矩阵
P=[5;3;4;1];%获取时计数从1开始
P_1=T*P;
plot3(P(1,1),P(2,1),P(3,1),'o');
hold on;
plot3(P_1(1,1),P_1(2,1),P_1(3,1),'o');
hold on;
trplot(T);
%% Q3-1 计算变换的逆
T2=[0.527 -0.574 0.628 2;0.369 0.819 0.439 5;-0.766 0 0.643 3;0 0 0 1]
T_tro=[0.527 -0.574 0.628;0.369 0.819 0.439;-0.766 0 0.643]
T_pos=[2;5;3]
T_pos2=[];
T_pos2(1,1)=-T_tro(:,1)'*T_pos;
T_pos2(2,1)=-T_tro(:,2)'*T_pos;
T_pos2(3,1)=-T_tro(:,3)'*T_pos;
a=[0 0 0 1];
T2_1_1=[T_tro',T_pos2];
T2_1=[T2_1_1;a]
T2_2=inv(T2)
%% Q3-2 计算变换的逆
T2=[0.92 0 0.39 5;0 1 0 6;-0.39 0 0.92 2;0 0 0 1];
T_tro=[0.92 0 0.39;0 1 0;-0.39 0 0.92];
T_pos=[5;6;2];
T_pos2=[];
T_pos2(1,1)=-T_tro(:,1)'*T_pos;
T_pos2(2,1)=-T_tro(:,2)'*T_pos;
T_pos2(3,1)=-T_tro(:,3)'*T_pos;
a=[0 0 0 1];
T2_1_1=[T_tro',T_pos2];
T2_1=[T2_1_1;a];
T2_2=inv(T2);
%% Q4  绕o轴转-β角，绕a轴转-α角
%% Q5-1 获取三个角度值
clc;clear
syms r b g
e1=r*sin(b)*cos(g)-3.1375;
e2=r*sin(b)*sin(g)-2.195;
e3=r*cos(b)-3.214;
[r,b,g]=vpasolve([e1,e2,e3],[r,b,g]);

r_deg=round(r);%round表示保留整数
g_deg=round(rem(g*180/pi,360));%rem(x,y):求整除x/y的余数
b_deg=round(rem(b*180/pi,360));
%% Q5-2 求原姿态矩阵
%方法一：直接带入rgb
T=trotz(g)*troty(b)*transl(0,0,r);
%方法二：逆回去
Tsph=[1,0,0,3.1375;0,1,0,2.195;0,0,1,3.214;0,0,0,1];
T2=Tsph*inv(trotz(-g))*inv(troty(-b));
%% Q6 求位姿矩阵所必需的RPY角
%(函数没办法求出第二个结果)
T_tro=[0.527 -0.574 0.628;0.369 0.819 0.439;-0.766 0 0.643];
ZYX_RPY=roundn(tr2rpy(T_tro,'zyx','deg'),-1)%保留小数点后一位小数
%% Q7 求位姿矩阵所必需的欧拉角
%(函数添加flip可以求出另外一个解)
ZYZ_Euler1=roundn(tr2eul(T_tro,'deg'),-1)
ZYZ_Euler2=roundn(tr2eul(T_tro,'deg','flip'),-1)
%% Q8-1 计算总变换
T=roundn(trotx(45,'deg')*trotz(60,'deg')*transl(0,0,3)*transl(0,6,0)*trotx(60,'deg'),-2)
%% 8-2 直角坐标和RPY的组合构型
ZYZ_Euler1=roundn(tr2eul(T(1:3,1:3),'deg'),-1)
ZYZ_Euler2=roundn(tr2eul(T(1:3,1:3),'deg','flip'),-1)
%% Q9-1 计算总变换
T=trotx(45,'deg')*trotz(60,'deg')*transl(5,0,0)*troty(60,'deg')*transl(0,0,3)
%% Q9-2 直角坐标和RPY的组合构型
ZYX_RPY=roundn(tr2rpy(T(1:3,1:3),'zyx','deg'),-1)%保留小数点后一位小数
%% Q10-1 构型变换RTH
UTR=[0 -1 0 2;1 0 0 -1;0 0 1 0;0 0 0 1]
UTObj=[1 0 0 1;0 0 -1 4;0 1 0 0;0 0 0 1]
RTH=inv(UTR)*UTObj
%% 10-2 不可以，因为球坐标变换矩阵的第3行第2列元素为0
%% 10-3 
ZYZ_Euler1=roundn(tr2eul(RTH(1:3,1:3),'deg'),-1)
ZYZ_Euler2=roundn(tr2eul(RTH(1:3,1:3),'deg','flip'),-1)
