clc;clear;
%定义机械臂
L(1)=Link([0,138,0,pi/2]);
L(2)=Link([0,0,135,0]);
L(3)=Link([0,0,147,0]);
%约束参数范围
L(1).qlim=[-pi/2,pi/2];
L(2).qlim=[0,deg2rad(85)];
L(3).qlim=[-deg2rad(95),deg2rad(10)];
Dobot=SerialLink(L,'name','Dobot');
x_start=deg2rad([0 0 0]);%各个关节初始转角
figure(1);
view(3);
Dobot.plot(x_start,'workspace',[-600 600 -600 600 -600 600],'tilesize',200);
%% 从[200 120 40]到[220 -150 220],轨迹为直线
T1=transl(200,120,40);T2=transl(220,-150,220);
T=ctraj(T1,T2,50);%根据初始位置和最终位置，生成一系列位姿矩阵
Line=transl(T);
plot3(Line(:,1),Line(:,2),Line(:,3),'m-','LineWidth',1);
q = Dobot.ikine(T,'mask',[1 1 1 0 0 0]);
view(3);%调整了一下角度，方便观察%
Dobot.plot(q,'tilesize',200);%画出机器人运动轨迹
%% 画圆，圆心[175 0 5]，半径R=50
B =(0:1:100)'; 
C_cen = [185 0 50];r = 60;theta = ( B/B(end) )*2*pi;%定义圆心、半径和圆心角
C_p = (C_cen + r*[cos(theta) sin(theta) zeros(size(theta))])';%圆周上点的空间坐标
T = transl(C_p');
q = Dobot.ikine(T,'mask',[1 1 1 0 0 0]);
hold on;
plot3(C_p(1,:),C_p(2,:),C_p(3,:),'b');%画出圆
view(3);
Dobot.plot(q,'workspace',[-600 600 -600 600 -600 600],'tilesize',200);%画出机器人的运动轨迹
%% 写“十”字
%横
T1=transl(180,55,20);T2=transl(180,-55,20);
%竖
T3=transl(220,0,20);T4=transl(80,0,20);
%分解起点到终点的变换矩阵
%横
T_h=ctraj(T1,T2,50);Lineh=transl(T_h);
%竖
T_s=ctraj(T3,T4,50);Lines=transl(T_s);
hold on
%绘制“十”字
plot3(Lineh(:,1),Lineh(:,2),Lineh(:,3),'r-','LineWidth',1.5);
plot3(Lines(:,1),Lines(:,2),Lines(:,3),'m-','LineWidth',1.5);
%求逆
h_inv = Dobot.ikine(T_h,'mask',[1 1 1 0 0 0]);s_inv = Dobot.ikine(T_s,'mask',[1 1 1 0 0 0]);
%机器人绘制“十”字
view(3);
Dobot.plot(h_inv,'tilesize',200);
Dobot.plot(s_inv,'tilesize',200);