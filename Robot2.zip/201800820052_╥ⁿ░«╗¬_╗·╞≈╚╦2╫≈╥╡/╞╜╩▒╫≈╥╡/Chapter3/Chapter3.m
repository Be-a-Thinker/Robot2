%% %%%%%%%%%%第三章课后作业
%% Q1
T=[0 0 1 2; 1 0 0 7; 0 1 0 5;0 0 0 1];
T2=trotz(0.15)*transl(0.1,0.1,0.3)*T
dT=T2-T
%% Q2
T=[1 0 0 5;0 0 1 3;0 -1 0 8;0 0 0 1];
dT=[0 -0.1 -0.1 0.6;0.1 0 0 0.5;-0.1 0 0 -0.5;0 0 0 0];
delta=dT*inv(T)
delta_T=inv(T)*dT
%% Q3
%Q3-a
A=[0 0 1 10;1 0 0 5;0 1 0 0;0 0 0 1];
A2=transl(1,0,0.5)*troty(0.1)*A;
dA=A2-A;
delta=dA*inv(A)
%Q3-b
delta_A=inv(A)*dA
%% Q4
% Q4-1
T1=[1 0 0 5;0 0 -1 3;0 1 0 6;0 0 0 1];
T2=[1 0 0.1 4.8; 0.1 0 -1 3.5;0 1 0 6.2;0 0 0 1];
Q=T2*inv(T1)
% Q4-b
dT=T2-T1;
delta=dT*inv(T1)
% Q4-c
%(平移，旋转）=(0.1 0 0.2,0 0 0.1)
%% Q5
J=[8 0 0 0 0 0 ;-3 0 1 0 0 0;0 10 0 0 0 0 ;0 1 0 0 1 0;0 0 0 1 0 0 ;-1 0 0 0 0 1];
T=[0 1 0 10;1 0 0 5;0 0 -1 0;0 0 0 1];
vector_d_point=[0;0.1;-0.1;0.2;0.2;0];
vector_d=J*vector_d_point%关节的微分变化
%坐标系的变化
trans_matrix=trotx(vector_d(4))*troty(vector_d(5))*trotz(vector_d(6))*transl(vector_d(1),vector_d(2),vector_d(3))
T2=trans_matrix*T%手坐标系新位置
delta=trans_matrix-eye(4)%微分算子
dT=delta*T
%% 综合作业
clc;clear;
%% 定义相关变量
L1=4;L2=3;L3=2;dt=0.1;Delta=[0.2;-0.3;-0.2]*dt;%沿坐标系的微分运动
theta0=deg2rad([10,20,30]);%关节初始角度
theta1=theta0(1);theta2=theta0(2);theta3=theta0(3);%三个关节转角的初始值
Q=theta0;j=0;%记录循环次数
%% 构建机器人
L(1)=Link([0,0,L1,0]);%构建连杆1
L(2)=Link([0,0,L2,0]);%构建连杆2
L(3)=Link([0,0,L3,0]);%构建连杆3
Pl3R=SerialLink(L,'name','Pl3R');%建立机器人
figure(1);clf;view(3);
Pl3R.plot(theta0,'workspace',[-4 15 -9 13 -7 7],'tilesize',3);%画出机器人初始构型
%% 迭代求解
for i=0:dt:5
    T01=trotz(theta1)*transl(L1,0,0);
    T12=trotz(theta2)*transl(L2,0,0);
    T23=trotz(theta3)*transl(L3,0,0);
    T13=T12*T23;
    T03=T01*T12*T23;%总变换矩阵
    % 求解相对于T3的雅可比矩阵J
    J(1,1)=-T03(1,1)*T03(2,4)+T03(2,1)*T03(1,4);
    J(2,1)=-T03(1,2)*T03(2,4)+T03(2,2)*T03(1,4);
    J(3,1)=T03(3,3);
    J(1,2)=-T13(1,1)*T13(2,4)+T13(2,1)*T13(1,4);
    J(2,2)=-T13(1,2)*T13(2,4)+T13(2,2)*T13(1,4);
    J(3,2)=T13(3,3);
    J(1,3)=-T23(1,1)*T23(2,4)+T23(2,1)*T23(1,4);
    J(2,3)=-T23(1,2)*T23(2,4)+T23(2,2)*T23(1,4);
    J(3,3)=T23(3,3);
    %转换成相对于T0坐标系（很重要！！!）
    J0=T03(1:3,1:3)*J;
    Del_theta=J0\Delta;%求出各个关节转角增量(逆微分运动方程)
    Q(1)=Q(1)+Del_theta(1);Q(2)=Q(2)+Del_theta(2);Q(3)=Q(3)+Del_theta(3);
    theta1=Q(1);theta2=Q(2);theta3=Q(3);%为下一次求解赋值，当前关节角度值
    
    hold on
    T=Pl3R.fkine(Q);%求机器人末端位姿矩阵
    M(1)=T.t(1);M(2)=T.t(2);M(3)=rad2deg(acos(T.n(1)));%取机器人末端位置x,y和thetaZ
    hold on
    plot3(M(1),M(2),0,'r+')%画出末端位置
    j=j+1;%循环次数
    A_Rox(j,:)=Q;%把每次得到的各个关节转角记录下来
    Del_theta_total(j,:)=Del_theta;%把每次得到的各个关节的增量转角记录下来
    M_history(j,:)=M;%把每次末端坐标系的x，y和绕z轴的转角记录下来，按行保存
end
%% 绘制关节转角-时间曲线
A_Rox=rad2deg(A_Rox);%角度转换成弧度
Del_theta_total=rad2deg(Del_theta_total)/dt;%转换成关节角速度
figure(2);clf;
plot([0:dt:5],A_Rox(:,1),'r-',[0:dt:5],A_Rox(:,2),'b-',[0:dt:5],A_Rox(:,3),'g-')
title('关节转角-时间曲线');xlabel('时间');ylabel('角度');legend('theta1','theta2','theta3');
grid on;
%% 绘制角速度-时间曲线
figure(3);clf;
xlabel('时间');ylabel('角速度');title('角速度-时间曲线');legend('w1','w2','w3');
plot([0:dt:5],Del_theta_total(:,1),'r-',[0:dt:5],Del_theta_total(:,2),'b-',[0:dt:5],Del_theta_total(:,3),'g-')
grid on;
%% 绘制x,y,theta-时间曲线
figure(4);clf;
title('x,y,theta-时间曲线');yyaxis left;
plot(0:dt:5,M_history(:,1),'r-',0:dt:5,M_history(:,2),'b-');
xlabel('时间');ylabel('坐标');yyaxis right;
plot(0:dt:5,M_history(:,3),'g-');
grid on;
ylabel('角度');legend('x','y','thetaz');
%% 计算最终位姿矩阵
T_last=T
