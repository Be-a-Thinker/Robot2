%% 求关节角度、角速度-时间变化
%% 定义相关参数
clc;clear;
z_0=deg2rad([-60 90 30]);
s_1=0.5;s_2=0.2;s_3=0.1;
u_1=10;u_2=15;u_3=10;
u_0=[0 0 0];
T=[20 5 1];
L1=4;L2=3;L3=2;
%% 构建机械臂
L(1)=Link([0,0,L1,0]);
L(2)=Link([0,0,L2,0]);
L(3)=Link([0,0,L3,0]);
Robot3=SerialLink(L,'name','Robot3');
figure(1);
view(3);
Robot3.plot(z_0,'workspace',[-6 9 -6 6 -6 6],'tilesize',3);
%% 求变换矩阵T1,T2,T3
T1=trotz(z_0(1))*transl(L1,0,0);
T2=trotz(z_0(2))*transl(L2,0,0);
T3=trotz(z_0(3))*transl(L3,0,0);
%% 求坐标
R1=T1*[-L1/2;0;0;1];
R2=T1*T2*[-L2/2;0;0;1];
R3=T1*T2*T3*[-L3/2;0;0;1];
L(1).G=0;L(2).G=0;L(3).G=0;
L(1).Jm=0;L(2).Jm=0;L(3).Jm=0;
L(1).m=u_1;L(1).a=L1;L(2).m=u_2;L(2).a=L2;L(3).m=u_3;L(3).a=L3;
L(1).I=[0 0 s_1];L(2).I=[0 0 s_2];L(3).I=[0 0 s_3];
L(1).r=R1(1:3);L(2).r=R2(1:3);L(3).r=R3(1:3);
Robot3.gravity=[0,-9.8,0];
[t,q,qd]=Robot3.fdyn(4,T,z_0,u_0);
%% 画图
%三个关节角度随时间变化曲线
figure;
plot(t,q(:,1),'r-',t,q(:,2),'b-',t,q(:,3),'g')
title("角度-时间")
grid on
%三个关节角速度随时间变化曲线
figure
plot(t,qd(:,1),'r-',t,qd(:,2),'b-',t,qd(:,3),'g')
title("角速度-时间")
grid on



