%% Q1
%% 建立机械臂，定义变量
clc,clear;
%建立机械臂
g=9.8;r=7806;
r_x=0;r_y=0.5;r_z=0;delta_t=0.01;t=1;
s_1=1;s_2=0.5;s_3=0;
u_1=0.05*0.05*s_1*r;
u_2=0.05*0.05*s_2*r;
L(1)=Link([0,0,1,0]);L(2)=Link([0,0,0.5,0]);L(3)=Link([0,0,0,0]);
robot3r=SerialLink(L,'name','robot3r');

q_1=zeros(length(0:0.01:1)-1,1);q_1(1)=0;
q_2=zeros(length(0:0.01:1)-1,1);q_2(1)=0;
q_3=zeros(length(0:0.01:1)-1,1);q_3(1)=0;%角速度
p_01=[10*pi/180,90*pi/180,0];Q0=[10*pi/180,90*pi/180,0];
theta1=zeros(length(0:0.01:1),1);theta2=zeros(length(0:0.01:1),1);theta3=zeros(length(0:0.01:1),1);%角度
theta1(1)=(10*pi/180);theta2(1)=(90*pi/180);theta3(1)=(0);%角度的初始值

a1=zeros(length(0:0.01:1)-1,1);a2=zeros(length(0:0.01:1)-1,1);a3=zeros(length(0:0.01:1)-1,1);%角加速度
T2=zeros(length(0:0.01:1)-1,1);T3=zeros(length(0:0.01:1)-1,1);

delta_x=r_x*delta_t;delta_y=r_y*delta_t;vz=r_z*delta_t;%微分运动
d_x=[delta_x;delta_y;0;0;0;vz];D=[delta_x;delta_y;vz];
deta1=transl(delta_x,delta_y,0)*trotz(vz)-eye(4);%变化量

T_0=robot3r.fkine(Q0)%初始变换矩阵
T_0 =[ 
   -0.1736   -0.9848         0     0.898
    0.9848   -0.1736         0    0.6661
         0         0         1         0
         0         0         0         1];
%% 迭代求解
for i=2:1:101
    T_01=trotz(theta1(i-1))*transl(s_1,0,0);
    T12=trotz(theta2(i-1))*transl(s_2,0,0);
    T23=trotz(theta3(i-1))*transl(s_3,0,0);
    T13=T12*T23;%关节2到关节3的变换矩阵
    T_03=T_01*T12*T23;%总变换矩阵
    % 求相对于T3坐标系的雅可比矩阵
    P(1,1)=-T_03(1,1)*T_03(2,4)+T_03(2,1)*T_03(1,4);
    P(1,2)=-T13(1,1)*T13(2,4)+T13(2,1)*T13(1,4);
    P(1,3)=-T23(1,1)*T23(2,4)+T23(2,1)*T23(1,4);
    P(2,1)=-T_03(1,2)*T_03(2,4)+T_03(2,2)*T_03(1,4);
    P(2,2)=-T13(1,2)*T13(2,4)+T13(2,2)*T13(1,4);
    P(2,3)=-T23(1,2)*T23(2,4)+T23(2,2)*T23(1,4);
    P(3,1)=T_03(3,3);    
    P(3,2)=T13(3,3);
    P(3,3)=T23(3,3); 
    R0=T_03(1:3,1:3);
    
    %逆微分运动方程 
    E0=R0*P;delta_theta=E0\D;
    Q0(1)=delta_theta(1)+Q0(1);Q0(2)=delta_theta(2)+Q0(2);Q0(3)=delta_theta(3)+Q0(3);  
    q_1(i)=delta_theta(1)/delta_t;q_2(i)=delta_theta(2)/delta_t;q_3(i)=delta_theta(3)/delta_t; 
    theta1(i)=Q0(1);theta2(i)=Q0(2);theta3(i)=Q0(3);
 
    a1(i-1)=(q_1(i)-q_1(i-1))/delta_t;a2(i-1)=(q_2(i)-q_2(i-1))/delta_t;a3(i-1)=(q_3(i)-q_2(i-1))/delta_t;
    T1=[1/3*u_1*s_1*s_1+u_2*s_1*s_1+1/3*u_2*s_2*s_2+u_2*s_1*s_2*cos(theta2(i)) 1/3*u_2*s_2*s_2+1/2*u_2*s_1*s_2*cos(theta2(i));1/3*u_2*s_2*s_2+1/2*u_2*s_1*s_2*cos(theta2(i)) 1/3*u_2*s_2*s_2]*[a1(i-1);a2(i-1)]+[0 -1/2*u_2*s_1*s_2*sin(theta2(i));1/2*u_2*s_1*s_2*sin(theta2(i)) 0 ]*[q_1(i)*q_1(i);q_2(i)*q_2(i)]+[-u_2*s_1*s_2*sin(theta2(i)) 0; 0 0]*[q_1(i)*q_2(i);q_2(i)*q_1(i)]+[(1/2*u_1+u_2)*g*s_1*cos(theta1(i))+1/2*u_2*g*s_2*cos(theta1(i)+theta2(i));1/2*u_2*g*s_2*cos(theta1(i)+theta2(i))];
    T2(i-1)=T1(1);T3(i-1)=T1(2);  
end
%% 关节角度-时间曲线
x=0:0.01:1;
figure,
plot(x,theta1,'-r',x,theta2,'-b')    
legend('theta1','theta2');   
title('关节角度-时间曲线')
%% 关节角速度-时间曲线
m1=0:0.01:1;
figure,
plot(m1,q_1,'-r',m1,q_2,'-b')    
legend('q_1','q_2');   
title('关节角速度-时间曲线')
%% x,y,θ-时间曲线
x_over=s_1*cos(theta1)+s_2*cos(theta1+theta2);
y_end=s_1*sin(theta1)+s_2*sin(theta1+theta2);
theta_end=theta1+theta2;
figure,
plot(x,x_over,'-r',x,y_end,'-b',x,theta_end,'-g')
legend('x','y','θ'); 
title(' x,y,θ-时间曲线')
%% 关节角加速度-时间曲线
figure,
m1=0.01:0.01:1;
plot(m1,a1,'-r',m1,a2,'-b')    
legend('a1','a2'); 
title('关节角加速度-时间曲线')
%% 关节转驱动力-时间曲线
figure,
m1=0.01:0.01:1;
plot(m1,T2,'-r',m1,T3,'-b')    
legend('T1','T2'); 
title('关节转驱动力-时间曲线')
